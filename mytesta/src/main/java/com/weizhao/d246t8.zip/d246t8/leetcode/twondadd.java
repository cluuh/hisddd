package com.weizhao.leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 链表的和
 */

public class twondadd {
    public static void main(String[] args) {
        ListNode listNode = ListNode.setNodByNum(123456);
        ListNode listNode1 = ListNode.setNodByNum(1234569);
        ListNode listNode2 = addTwoNumbers(listNode1, listNode);
        //1同时遍历链表
        //2创建第三个链表
        //3存储到新链表中

    }
    public static ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode res = new ListNode();
        ListNode resTemp=res;
        ListNode l1Temp=l1;
        ListNode l2Temp=l2;
        int jinwei=0;
        while(true){
            int gewei;
            int add1=0;
            int add2=0;
            if(l1Temp!=null){
                add1=l1Temp.val;
                l1Temp=l1Temp.next;
            }
            if(l2Temp!=null){
                add2=l2Temp.val;
                l2Temp=l2Temp.next;
            }
            int addNum=add1+add2+jinwei;
            gewei=addNum%10;
            jinwei=addNum/10;

            resTemp.val=gewei;
            if(jinwei==0 && l1Temp==null && l2Temp==null){
                break;
            }
            ListNode listNode = new ListNode();
            resTemp.next=listNode;
            resTemp=listNode;
        }
        return res;
    }


}
class ListNode{
    int val;
    ListNode next;
    ListNode(){}


    public ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
    public ListNode(int val) {
        this.val = val;
    }

    public static ListNode setNodByNum(long num){
        ListNode res=null;
        while (true){
            if(num/10==0){
                ListNode listNode = new ListNode();
                listNode.val=(int)num;
                listNode.next=res;
                res=listNode;
                break;
            }
            long tempNum=num%10;
            num=num/10;
            ListNode listNode = new ListNode();
            listNode.val=(int)tempNum;
            listNode.next=res;
            res=listNode;
        }
        return res;
    }
}
